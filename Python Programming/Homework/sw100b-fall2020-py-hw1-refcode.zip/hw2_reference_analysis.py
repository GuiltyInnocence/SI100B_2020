# =============================================================================#
#                   Homework 2: Flight Analytics with SQL                     #
#                            Reference Solution                               #
#       SI 100B: Introduction to Information Science and Technology B         #
#                      Fall 2020, ShanghaiTech University                     #
#             Author: Wu Daqian <wudq1>, Diao Zihao <hi@ericdiao.com>         #
#                         Last motified: 09/06/2020                           #
# =============================================================================#


"""
Disclaimer: this code is only a proof of concept instead of a best practice.
"""

import re


class Error(Exception):
    """Base class for other exceptions"""
    pass


class Row:
    """
    The `Row` class.

    You are building the row class here.
    """

    def __init__(self, keys, data):
        # checking whether the input parameters is of right type and raise corresponding exceptions
        if not isinstance(keys, list) or not isinstance(data, list):
            raise TypeError('`data` and `key` must be list.')
        if len(data) != len(keys):
            raise KeyError('Length of `data` and `keys` are not consistent.')
        if len(data) == 0:
            raise ValueError('Empty row.')

        # store id, keys and data of Row in private variables
        self.__keys = keys
        # data is processed by __normalize_data function
        self.__data = [Row.__normalize_data(i, keys[data.index(i)]) for i in data]
        self.__id = self.__data[self.__keys.index('ID')]
        # sort keys
        self.__sort_key()

    def __getitem__(self, key):
        # checking whether the input parameters is of right type and raise corresponding exceptions
        try:
            # find index of input keys in self.__keys
            idx = self.__keys.index(key)
        except ValueError:
            raise KeyError('Key `{}` is not in this row'.format(key))
        # return the value of input key by the index we computed above
        return self.__data[idx]

    def __setitem__(self, key, value):
        # checking whether the input parameters is of right type and raise corresponding exceptions
        try:
            # find index of input keys in self.__keys
            idx = self.__keys.index(key)
        except ValueError:
            raise KeyError('Key `{}` is not in this row'.format(key))
        # assign value of input key of value returned by Row.__normalize_data given input parameter value and key
        self.__data[idx] = Row.__normalize_data(value, key)

    def __len__(self):
        return len(self.__keys)

    def __lt__(self, other):
        # checking whether the input parameters is of right type and raise corresponding exceptions
        if (not isinstance(other, Row)) or self.__keys != other.__keys:
            raise TypeError
        # compare two row by their ID
        return self.__getitem__('ID') < other.__getitem__("ID")

    def keys(self):
        return self.__keys.copy()

    def get_id(self):
        return self.__id

    def __iter__(self):
        # return an instance of RowIter when iterator is called
        return RowIter(self)

    def __sort_key(self):
        # sort self.__keys
        orig_key = self.__keys
        orig_data = self.__data
        self.__keys = sorted(self.__keys)
        # change the order of self.__data after self.__key is sorted
        self.__data = [orig_data[orig_key.index(idx)] for idx in self.__keys]

    @staticmethod
    def __normalize_data(data, key):
        # if key is not in string type list, convert data to integer
        if key not in ["AIRLINE", "TAIL_NUMBER", "ORIGIN_AIRPORT", "DESTINATION_AIRPORT"]:
            # if key is AVG(field), convert data to float
            if re.search('AVG\\([a-z_A-Z]+\\)', key):
                return float(data)
            return int(data)
        # leave data alone as a string
        return data


class RowIter():

    def __init__(self, row):
        # init RowIter by store Row instance in self.row
        self.row = row
        self.idx = -1

    def __next__(self):
        self.idx += 1
        # check if iteration should stop
        if self.idx >= len(self.row.keys()):
            raise StopIteration
        return self.row.keys()[self.idx]


class Table():
    """
    The `Table` class.

    This class represents a table in your database. The table consists
    of one or more lines of rows. Your job is to read the content of the table
    from a CSV file and add the support of iterator to the table. See the
    specification in README.md for detailed information.
    """

    def __init__(self, filename, rows=None, keys=None):
        # store filename in self.__table_name
        self.__table_name = filename
        if isinstance(rows, list):
            # initialize Table by a list of Rows and keys
            self.__rows = list(rows)
            self.__keys = keys.copy()
        else:
            # initialize Table by a csv file
            with open(filename) as f:
                self.__keys = [key.strip()
                               for key in f.readline().strip().split(',')]
                rows_text = f.readlines()
                self.__rows = []
                for row_text in rows_text:
                    if row_text == '\n':
                        continue
                    row = [field.strip()
                           for field in row_text.strip().split(',')]
                    if len(row) != 0:
                        self.__rows.append(Row(self.__keys, row))
        # above two initialization method should fulfill self.__keys and self.__rows
        self.__keys = sorted(self.__keys)
        self.__rows = sorted(self.__rows)

    def __iter__(self):
        self.__iter_idx = -1
        return self

    def __next__(self):
        self.__iter_idx += 1
        if self.__iter_idx >= len(self.__rows):
            raise StopIteration
        return self.__rows[self.__iter_idx]

    def __getitem__(self, id):
        # check if input id has corresponding row in self.__rows
        for row in self.__rows:
            if row["ID"] == id:
                return row
        raise ValueError

    def __len__(self):
        return len(self.__rows)

    def keys(self):
        return self.__keys

    def get_table_name(self):
        return self.__table_name

    def export(self, columns, filename=None):
        # if filename is None then use self.__table_name instead
        fn = filename if filename else self.__table_name

        # collect keys required to be export
        keys = list()
        if columns:
            for k in self.__keys:
                if k in columns:
                    keys.append(k)
        else:
            keys = self.__keys
        # export Table data given keys collected above
        with open(fn, mode='w+') as f:
            # write keys
            f.write('{}\n'.format(','.join(keys)))
            # write rows
            for r in self.__rows:
                items = list()
                for k in r:
                    if k in keys:
                        items.append(str(r[k]))
                f.write('{}\n'.format(','.join(items)))


class Query():
    """
    The `Query` class.
    """

    def __init__(self, query):
        # checking whether the input parameters is of right type and raise corresponding exceptions
        if isinstance(query['filename'], str):
            # store data source
            self.__from = query['filename']
        else:
            raise TypeError
        if isinstance(query['condition'], list):
            # parse the conditions and store result in self.__where
            self.__where = list()
            for i in query['condition']:
                key = i['key']
                val = i['value']
                op = i['operator']
                self.__where.append((key.strip(), Query.__normalize_data(val.strip(), key), op.strip()))
        else:
            raise TypeError
        # filter rows given self.__where and Table instance initialized by filename in query
        self._do_filter(Table(self.__from), self.__where)

    def as_table(self):
        # return a Table instance given self.__original_table, self.__selected_rows and self.self.__cols
        return Table(self.__original_table.get_table_name(), rows=self.__selected_rows, keys=self.__cols)

    def _do_filter(self, table, conds):
        self.__original_table = table
        self.__selected_rows = []
        self.__cols = self.__original_table.keys()
        # fetch every row of input Table instance
        for row in self.__original_table:
            # check if row satisfy all the conditions
            b = True
            for cond in conds:
                b = b and Query.__do_cmp(row, cond[0], cond[1], cond[2])
            # if row satisfy all the conditions, append it into self.__selected_rows
            if b:
                self.__selected_rows.append(row)

    @staticmethod
    def __do_cmp(row, key, var, op):
        # if data is integer type, convert var from string to integer
        if key not in ["AIRLINE", "TAIL_NUMBER", "ORIGIN_AIRPORT", "DESTINATION_AIRPORT"]:
            var = int(var)
        if op == '==':
            return row[key] == var
        elif op == '<=':
            return row[key] <= var
        elif op == '>=':
            return row[key] >= var
        elif op == '!=':
            return row[key] != var
        elif op == '>':
            return row[key] > var
        elif op == '<':
            return row[key] < var
        else:
            raise SyntaxError

    @staticmethod
    def __normalize_data(data, key):
        if key not in ["AIRLINE", "TAIL_NUMBER", "ORIGIN_AIRPORT", "DESTINATION_AIRPORT"]:
            return int(data)
        return data


class AggQuery(Query):
    """
    The `AggQuery` class
    """

    def __init__(self, query: dict):
        # load filename from query
        if isinstance(query['filename'], str):
            self.__from = query['filename']
        else:
            # raise TypeError if filename is not string
            raise TypeError

        # translate into sql format with single selection
        # since ID is the hardwired primary key, the additional selection is appended to 'ID'
        # e.g. SELECT ID, GROUP BY(column) or SELECT ID, AVG(column)
        self.__select = ['ID']
        if query.get('group_by'):
            self.__select.append(query['group_by'])
        self.__select.append(query['function'] + '({})'.format(query['column']))

        # translate into sql format
        # condition in sql corresponds to WHERE
        # the key, value,  operator is appended as a triple after normalizing
        if isinstance(query['condition'], list):
            self.__where = list()
            for i in query['condition']:
                key = i['key']
                val = i['value']
                op = i['operator']
                self.__where.append((key.strip(), AggQuery.__normalize_data(val.strip(), key), op.strip()))
        else:
            # raise TypeError if condition is not  in the form of list
            raise TypeError

        # initialize the table
        self.__original_table = Table(filename=self.__from)
        table = self.__original_table

        # perform function operation on the column desired
        cols = [self.__get_func(col)[1] for col in self.__select]
        # perform filter to the table to get rows
        rows = self._do_filter(table, self.__where)

        # when the argquery selected is GROUP_BY
        if query.get('group_by'):
            group_col = query['group_by']
            groups = {}
            # append rows into group, if not initialized, then initialize the new group
            for row in rows:
                try:
                    groups[row[group_col]].append(row)
                except:
                    groups[row[group_col]] = [row, ]
            # perform iteration over the rows to group
            rows = []
            for group in groups:
                this_row = {}
                for col in self.__select:
                    func, ori_col = self.__get_func(col)
                    func = func if func else lambda l: l[0] if len(l) else None
                    this_row[col] = func([r[ori_col] for r in groups[group]])
                # initialize the grouped row as a row
                rows.append(Row(list(this_row.keys()), [
                    this_row[i] for i in this_row.keys()]))
        else:
            # if not GROUP BY, then perform function
            if "ID" not in self.__select:
                # constrain in selection the primary key ID
                self.__select.append("ID")
            for col in self.__select:
                # for each selected col
                # get the function to perform as func
                func, col_name = self.__get_func(col)
                # pick out this column of data
                this_col_data = []
                for row in rows:
                    this_col_data.append(row[col_name])
                # if there is a function to perform
                if func:
                    val = func(this_col_data)
                    for row in rows:
                        row[col_name] = val
            # initialize the newly calculated rows
            new_rows = []
            for row in rows:
                this_row = {}
                for col in self.__select:
                    # get original column that we performed the operation on
                    _, ori_col = self.__get_func(col)
                    this_row[col] = row[ori_col]
                new_rows.append(Row(list(this_row.keys()), [
                    this_row[i] for i in this_row.keys()]))
            rows = new_rows

        # get results
        self.__selected_rows = rows
        self.__cols = self.__select

    def _do_filter(self, table, conds):
        # filter performed over rows
        cols = self.__original_table.keys()
        self.__original_table = table
        self.__selected_rows = []
        if "ID" not in cols:
            # contrain on the primary key ID
            cols.append("ID")
        self.__cols = cols
        for row in self.__original_table:
            # for each row in the original table
            b = True
            # apply all the  condition constrains
            for cond in conds:
                b = b and AggQuery.__do_cmp(row, cond[0], cond[1], cond[2])
            if b:
                self.__selected_rows.append(
                    Row(cols, [row[k] for k in cols]))
        return self.__selected_rows

    def as_table(self):
        # provied the aggquery as a table
        return Table(self.__original_table.get_table_name(), rows=self.__selected_rows, keys=self.__cols)

    def __get_func(self, field: str) -> tuple:
        # get function operation
        # return the function to use and the column to operate on as a tuple
        _sum = sum
        _max = max
        _min = min
        _avg = lambda lst: sum(lst) / len(lst)

        if field.endswith(')'):
            # check which operation to perform
            if field.startswith('SUM('):
                return _sum, field[4:-1]
            elif field.startswith('AVG('):
                return _avg, field[4:-1]
            elif field.startswith('MAX('):
                return _max, field[4:-1]
            elif field.startswith('MIN('):
                return _min, field[4:-1]
            else:
                return None, field[4:-1]
        else:
            return None, field

    @staticmethod
    def __normalize_data(data, key):
        # these keys  need  to be converted into integers  when comparing
        if key not in ["AIRLINE", "TAIL_NUMBER", "ORIGIN_AIRPORT", "DESTINATION_AIRPORT"]:
            return int(data)
        return data

    @staticmethod
    def __do_cmp(row, key, var, op):
        # operation  comparison
        if op == '==':
            return row[key] == var
        elif op == '<=':
            return row[key] <= var
        elif op == '>=':
            return row[key] >= var
        elif op == '!=':
            return row[key] != var
        elif op == '>':
            return row[key] > var
        elif op == '<':
            return row[key] < var
        else:
            raise SyntaxError
