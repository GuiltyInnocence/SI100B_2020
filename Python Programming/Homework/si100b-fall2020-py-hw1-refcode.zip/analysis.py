from typing import List, Tuple


def read_csv_for_data(filename: str):
    """
    Task 0
    @filename: the file name of the file you need to read in;
    @return: your custom data structure.
    """
    with open(filename) as f:  # Open the file `filename`, store the file handler in `f`
        header = {v: i for i, v in enumerate(f.readline().strip().split(","))}
        # The line above do the following things:
        # 1. Read the first line, split the line using `,` as the delimiter, store the result in a list. e.g. ["a ", "b"];
        # 2. Strip all the string in the list. Result: ['a'. 'b'];
        # 3. enumerate() will take in an iterable, return an iterable with every item in the iterable numbered (converted to a tuple);
        #    e.g., [i for i in enumerate(['a', 'b'])] will return [(0, "a"), (1, "b")]
        #    Think about why we would like to add a index to the field id.
        data = [l.strip().split(",") for l in f.readlines()]
        # The line above do the following things:
        # 1. Read all the rest lines, store the result in a list
        # 2. split() all the lines in the list with ","
        # 3. clean up the whitespace in every fields
    # the file handler `f` will automatically close at this point
    return data, header
    # return the data and header.


def task1(filename: str):
    """
    Task 2
    @filename: the file name of the data file.
    @return: a list of flight number strings.
    """
    # Read in the data from the CSV file `filename` with tools you build in task 0.
    data, header = read_csv_for_data(filename)
    return [i[1] for i in sorted((int(row[header["DISTANCE"]]), row[header["AIRLINE"]] + row[header["FLIGHT_NUMBER"]]) for row in data if int(row[header["DISTANCE"]]) > 1500)]
    # 1. Iterate through all the data rows, find out which flight has `DISTANCE` larger than 1500 (after doing the conversion);
    # 2. For every line we retrived in the last step, get the flight number (e.g., CA981), put the distance and the flight number into a tuple for every flight;
    # 3. Sort the list with sorted(), since the items in the list are all tuple, sorted will automatically sort it with `DISTANCE` first then flight number.
    # Side note: this one-liner could also be re-write to a for loop without changing the meaning. Think about how.


def task2(filename: str, airline: str, key: str, value) -> int:
    """
    Task 2
    @filename: the file name of the data file.
    @airline: the airline as a string of IATA code.
    @key: the key that we want to filter against.
    @value: the value that we want to filter against.
    @return: the number of flights that satisfy as an integer.
    """
    # Read in the data from the CSV file `filename` with tools you build in task 0.
    data, header = read_csv_for_data(filename)

    def trans(v):
        try:
            return int(v)
        except:
            return v
        # function trans():
        # Some kind of *abuse* of try/except to convert values that could be converted to integer to integer while leave other values unchanged,
        # By enclose the int() function call in the try clause, we can catch the exception caused by an unsuccessful conversion and return the unchanged value in the except clause in this case.
    value = trans(value)  # Convert the parameter to integer if possible.
    return [row[header["AIRLINE"]] == airline and trans(row[header[key]]) < value for row in data].count(True)
    # 1. Iterate through the data rows and,
    # 2. Filter every row in the data with a list comprehension.
    #    If the condition is satisfied, `row[header["AIRLINE"]] == airline and trans(row[header[key]]) < value` will be replaced with a True in the result list, otherwise it will be False;
    # 3. Notice that in step 2, we have made a list that is full of `True` or `False`. The rows that satisfied the condition are converted to a True and those are not are converted to a False.
    #    To give the final result, we only need to count how many `True`s are there in the list. This is done with the `.count()` method of list.
    # Side note: this one-liner could also be re-write to one (or more) for loops without changing the meaning. Think about how.


def task3(filename: str) -> List[Tuple[str, float]]:
    """
    Task 3
    @filename: the file name of the data file.
    @return: a list of tuples with format of (airline, rate).
    """
    data, header = read_csv_for_data(filename)
    return sorted([(airline, task2(filename, airline, "ARRIVAL_DELAY", 0) /
                    [r[header["AIRLINE"]] == airline for r in data].count(True)) for airline in set(row[header["AIRLINE"]] for row in data)], key=lambda x: (-x[1], x[0]))
    # 1. Aggregate the data. Make a set (distinct) of all the airlines in the table.
    # 2. For every airlines in the set, iterate through all the rows to get the number of filghts from the airline in the table (works the same as in task 2);
    # 3. For every airline, call the function for task 2 to get the number of on-time flights from the company;
    # 4. The on-time rate of the given airline is the data in step 3 divided by the one in step 2. We return it as a tuple like `("CA", 1.00)` in the list from the list comprehension
    # 5. The sorted() function is called in the list to sort the result to the desiered order.
