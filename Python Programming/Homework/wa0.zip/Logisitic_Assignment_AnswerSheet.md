# Logisitic Assignment Answer Sheet

## Kind Reminder

- 请各位同学先**熟读**《[SI100B 课程学术行为规范（2020 秋季学期）](https://si100b.org/resource-policy/#policies)》，再作答下列题目；

- 作答时，请各位同学将答案填写至 Answer Sheet 中；

- 为了方便同学们作答与提交，我们准备 Markdown 和 PDF 两种格式的 Answer Sheet。各位同学在作答时，选用其中一种即可。

  如果选择使用 Markdown 版本的 Answer Sheet，推荐各位同学使用 [Typora](https://typora.io/) 作为编辑器。在后续的 Homework 与 Quiz 中你可能也会用到该软件；

- 本次作业请提交至 Gradescope。以下几种作答与提交方式供同学们参考：

  - 将 Answer Sheet 打印出来，手写作答。作答完毕后拍照/扫描上传至 Gradescope；
  - 直接使用可编辑版本（Markdown），作答完成后导出为 PDF 文件上交；

- 请各位同学将 Answer Sheet 上交至 Gradescope 时注意以下几点：

  - 请各位同学检查自己的账户信息中的全名（Full Name）是否为中文全名，邮箱地址（Email Address）是否为自己的上科大邮箱，学号（Student ID）是否为自己的上科大学号。如果各位在Logistic Assignment的截止日期前未将三者修改正确，则 Logistic Assignment 将**以0分处理**；

  - 作答与上传至 Gradescope 的作答结果**须使用 SI100B 课程组所提供的 Answer Sheet**，否则 Logistic Assignment 将**以0分处理**；

  - 请各位同学在上传自己的作答时，选择 Answer Sheet 中的答题表格（Answer Table）所在页码，并将其标注在 Gradescope 系统中的 Answer Table 的小题下。如果各位在提交时未标注 Answer Table 所在页码，则 Logistic Assignment 将会**被扣除50分**。

## Answer Table

| 题号 |  1   |  2   |  3   |  4   |  5   |
| :--: | :--: | :--: | :--: | :--: | :--: |
| 答案 |      |      |      |      |      |
| 题号 |  6   |  7   |  8   |  9   |  10  |
| 答案 |      |      |      |      |      |
| 题号 |  11  |  12  |  13  |  14  |  15  |
| 答案 |      |      |      |      |      |
| 题号 |  16  |  17  |  18  |  19  |  20  |
| 答案 |      |      |      |      |      |
| 题号 |  21  |  22  |  23  |  24  |  25  |
| 答案 |      |      |      |      |      |

